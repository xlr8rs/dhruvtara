$(document).ready(function() {

	$('select[name=author]').change(function () {
		// alert($('#id_author option:selected').val());
		// $('#id_institution').val($(this).attr('HELLO WORLD'));
	});

});